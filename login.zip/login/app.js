(function() {


    var checkLogin = (function() {
        $('#login').hide();
        var username = localStorage.getItem("username");
        var password = localStorage.getItem("password");
        var token = localStorage.getItem("token");
        var time = localStorage.getItem("time");

        if (password && username) {
            var url = "https://adm.fut-heroes.com/api/login";
            var data = {
                //do: "SignIn",
                //checkTime: time,
                do: "check_login",
                token: token,
                username: username,
                password: password,
                product: 3

            };

            $.post(url, data, function(result) {
                //var obj = jQuery.parseJSON(result);
                 if (result.status == 200) {
                     console.log(result);
                     
                //     location.href = "index.html";
                $('#login').hide();
                $('#logout').show();
                }else{
                    console.log(result);
                    cleanError();
                    $('#login').css('opacity', '1');
                    $('#login input').attr('disabled', false);
                    $('.loading').hide();
                    $('#login button').show();

                    // localStorage.removeItem("username");
                    // localStorage.removeItem("password");
                    $('#login').show();
                    $('#logout').hide();

                }

            });
        }

        $('#login').show();

    });

    checkLogin();
    var cleanError = (function() {
        $(".has_error").removeClass("has_error").css('border', 'solid 2px green');
        $(".error_message").remove();
    });

    var showError = (function(Element, Message) {
        Element.after("<p class=\"error_message text-danger\" style=\"padding:0px 20px 3px 20px\" >" + Message + "</p>");
        Element.focus();
        Element.addClass("has_error");
        Element.css('border', 'solid 2px red');
    });

    $('#login').on("submit", function(e) {
        
        e.preventDefault();
        //cleanError();
        if ($('#login #name').val().length < 4) {
            showError($('#login #name'), 'Please type username');
        } else if ($('#login #password').val().length < 5) {
            showError($('#login #password'), 'Please type password');
        } else {
            $('#login').css('opacity', '.5');
            $('#login input').attr('disabled', 'disabled');
            $('#login button').hide();

            $('#login .loading').show();


            var timeVar = Date.now();
            var url = "https://adm.fut-heroes.com/api/login";
            var data = {
                // do: "SignIn",
                // time: timeVar,
                do: "login",
                username: $('#login #name').val(),
                password: $('#login #password').val(),
                product: 3
            };


            $.post(url, data, function(result) {
                // console.log(result);
                //var obj = jQuery.parseJSON(result);
                if (result.status == 200) {
                    localStorage.setItem("token", result.token);

                    console.log(result.token);

                    localStorage.setItem("username", $('#login #name').val());
                    localStorage.setItem("password", $('#login #password').val());
                    //localStorage.setItem("time", timeVar);
                    $('#login').hide();
                    $('#logout').show();
                   //location.href = "index.html";


                } else {
                    cleanError();
                    $('#login').css('opacity', '1');
                    $('#login input').attr('disabled', false);
                    $('.loading').hide();
                    $('#login button').show();
                    showError($('#password'), result.msg);
                }

            });

        }
    });

    // var logout = document.getElementById('logout');
    // var login = document.getElementById('login');
    // logout.addEventListener('click', function(){
    //     localStorage.removeItem("username");
    //     localStorage.removeItem("password");
    //     logout.style.display = 'none';
    //     login.style.display = 'inline-block';
    // });

    $('#logout').on("click", function() {
        localStorage.removeItem("username");
        localStorage.removeItem("password");
        $('#login').show();
        $('#logout').hide();
        
    }); 



    // $('#login').on("submit", function(e) {
    //     e.preventDefault();
    //     var url = "http://localhost/mg23/public/api/login";
      
    //     fetch(url, {
    //       method: "POST",
    //       headers: {
    //         Accept: "application/json, text/plain, */*",
    //         "Content-Type": "application/json",
    //       },
    //       body: JSON.stringify({
    //         username: $('#login #name').val(),
    //         password: $('#login #password').val(),
    //       }),
    //     }).then((response) => response.json()).then((data) => {
    //         console.log(data);
    //         // code here //
    //         if (data.error) {
    //           alert("Error Password or Username"); /*displays error message*/
    //         } else {
    //                 localStorage.setItem("username", $('#login #name').val());
    //                 localStorage.setItem("password", $('#login #password').val());
    //                 //localStorage.setItem("time", timeVar);
    //                 $('#login').hide();

    //         //   window.open(
    //         //     "target.html"
    //         //   ); /*opens the target page while Id & password matches*/
    //         }
    //       })
    //       .catch((err) => {
    //         console.log(err);
    //       });
    //   });

   

})();